
/* Connect AVR128DA48 Curiosity Nano to Medium One and send temperature sensor data */

#include <atmel_start.h>
#include <atomic.h>
#include <stdio.h>
#include <string.h>

#define WIFI_SSID       "YOUR_INFO"
#define WIFI_PASSWORD   "YOUR_INFO"

#define MQTT_BROKER     "mqtt.mediumone.com"
#define MQTT_PORT       61618           /* encrypted port */
#define MQTT_USERNAME   "xxxxxxxxxxx/xxxxxxxxxxx"
#define MQTT_PASSWORD   "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/xxxxxxxxxxxxxxxxx"
#define MQTT_PUB_TOPIC  "0/xxxxxxxxxxx/xxxxxxxxxxx/mydevice"

#define PUB_INTERVAL_MS 3000
#define ENABLE_PUBLISH  1

// Types & constants

typedef enum {
	APP_STATE_INIT = 0,
	APP_STATE_RESET_BRIDGE,
	APP_STATE_INIT_BRIDGE,
	APP_STATE_INIT_BRIDGE_CONFIRM,
	APP_STATE_CONNECT_WIFI,
	APP_STATE_CONNECT_WIFI_CONFIRM,
	APP_STATE_CONNECT_MQTT,
	APP_STATE_CONNECT_MQTT_CONFIRM,
	APP_STATE_PUBLISH_SENSOR_DATA,
	APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM,
	APP_STATE_DISCONNECT_MQTT,
	APP_STATE_DISCONNECT_WIFI,
	APP_STATE_DISCONNECT_WIFI_CONFIRM,
	APP_STATE_TIMED_DELAY,
	APP_STATE_NONE
} APP_STATE_T;

typedef struct {
	uint32_t iteration;     // iteration count
	uint32_t timestamp;     // millisecond tick count
	int buttonState;        // 1=pressed, 0=released
	int16_t temp_c;			// object temperature C * 100
	int16_t temp_f;			// object temperature F * 100
	int16_t amb_temp_c;		// ambient temperature C * 100
	int16_t amb_temp_f;		// ambient temperature F * 100
} SENSOR_DATA_T;

APP_STATE_T app_state = APP_STATE_INIT;
APP_STATE_T next_app_state = APP_STATE_NONE;
uint32_t timed_delay_start = 0;
uint32_t timed_delay_duration = 0;

bool buttonPressed = false;
uint32_t buttonPressTime = 0;

#define SERIAL_BUF_SIZE 80

char read_buffer[SERIAL_BUF_SIZE] = {0};
char current_response[SERIAL_BUF_SIZE] = {0};
char last_response[SERIAL_BUF_SIZE] = {0};
int read_pos = 0;
int write_pos = 0;
bool new_response_available = 0;
uint32_t cmd_send_time;
int fail_count = 0;

char command[256];
SENSOR_DATA_T sensorData;

extern volatile uint32_t systick;	// in driver_isr.c

// Prototypes

void Delay_Ms(uint32_t ms);
void LED0_On(void);
void LED0_Off(void);
void Read_Sensors(SENSOR_DATA_T *sensorData);
void Process_USART0(void);
void Send_Command(char *cmd);
void Clear_Rx(void);
uint32_t Response_Elapsed_Time(void);
bool isOKResponse(char *p);
APP_STATE_T new_app_state(APP_STATE_T app_state);
void set_timed_delay(uint32_t delay_ms, APP_STATE_T next_state);
void reset_bridge(void);
void State_Machine(void);

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	// If USART Basic driver is in IRQ-mode, enable global interrupts.
	ENABLE_INTERRUPTS();

	Delay_Ms(3000);
	
	printf("Starting application\r\n");
	
	while (1) {

		Process_USART0();
		
		State_Machine();
		
	}

}

void Delay_Ms(uint32_t ms)
{
	uint32_t start = systick;
	while ((systick - start) < ms) {
	}
}

void LED0_On(void)
{
	LED0_set_level(false);
}

void LED0_Off(void)
{
	LED0_set_level(true);
}

void Read_Sensors(SENSOR_DATA_T *sensorData)
{
	// Read sensors and populate sensor data structure

	static uint32_t iteration = 0;
	int32_t tempC;
	int32_t tempF;
	uint8_t cmd;
	uint8_t resp[2];
	
	sensorData->iteration = iteration++;                            // sensor read count
	sensorData->timestamp = systick;                                // millisecond counter
	sensorData->buttonState = SW0_get_level() ? 0 : 1;              // 1=pressed, 0=released
	
	// Read TE temperature sensor
	
	SPI0_SS_set_level(false);
	
	cmd = 0xA1;														// read object temperature
	SPI_0_write_block(&cmd, 1);
	Delay_Ms(25);
	SPI_0_read_block(&resp[0], 1);
	Delay_Ms(10);
	SPI_0_read_block(&resp[1], 1);
			
	sensorData->temp_c = (resp[0] << 8) + resp[1];
	tempC = sensorData->temp_c;
	tempF = ((tempC * 9) / 5) + 3200;
	sensorData->temp_f = (int16_t)tempF;

	printf("Obj temp bytes (hex): %02X, %02X  temp_c = %d.%02d, temp_f = %d.%02d\r\n",
		resp[0], resp[1], sensorData->temp_c / 100, sensorData->temp_c % 100, sensorData->temp_f / 100, sensorData->temp_f % 100 );	

	Delay_Ms(10);
	
	cmd = 0xA0;														// read ambient temperature
	SPI_0_write_block(&cmd, 1);
	Delay_Ms(25);
	SPI_0_read_block(&resp[0], 1);
	Delay_Ms(10);
	SPI_0_read_block(&resp[1], 1);
	
	SPI0_SS_set_level(true);
	
	sensorData->amb_temp_c = (resp[0] << 8) + resp[1];
	tempC = sensorData->amb_temp_c;
	tempF = ((tempC * 9) / 5) + 3200;
	sensorData->amb_temp_f = (int16_t)tempF;
	
	printf("Amb temp bytes (hex): %02X, %02X  temp_c = %d.%02d, temp_f = %d.%02d\r\n",
	resp[0], resp[1], sensorData->amb_temp_c / 100, sensorData->amb_temp_c % 100, sensorData->amb_temp_f / 100, sensorData->amb_temp_f % 100 );	
}

void Process_USART0(void)
{
	if (USART_0_is_rx_ready()) {
		char ch = USART_0_read();
		if (ch == '\n') {  // end of response
			current_response[write_pos] = 0;
			strcpy(last_response, current_response);
			read_pos = 0;
			write_pos = 0;
			current_response[write_pos] = 0;
			new_response_available = 1;
		} else if (ch != 0 && ch != '\r') {  // ignore NUL & CR, keep rest
			current_response[write_pos++] = ch;
			current_response[write_pos] = 0;
		}
	}
}

void Send_Command(char *cmd)
{
	if (cmd != NULL) {
		read_pos = 0;
		write_pos = 0;
		current_response[write_pos] = 0;
		new_response_available = 0;
		Clear_Rx();
		while (*cmd) {
			USART_0_write(*cmd++);
		}
		cmd_send_time = systick;
	}
}

void Clear_Rx(void)
{
	while (USART_0_is_rx_ready()) {
		USART_0_read();
	}
}

uint32_t Response_Elapsed_Time(void)
{
	return systick - cmd_send_time;
}

bool isOKResponse(char *p)
{
	if (strncmp(p, "OK", 2) == 0) {
		return true;
		} else {
		return false;
	}
}

APP_STATE_T new_app_state(APP_STATE_T app_state)
{
	// Return next_app_state if it's not APP_STATE_NONE,
	// otherwise return app_state
	APP_STATE_T state = app_state;
	if (next_app_state != APP_STATE_NONE) {
		state = next_app_state;
		next_app_state = APP_STATE_NONE;
	}
	return state;
}

void set_timed_delay(uint32_t delay_ms, APP_STATE_T next_state)
{
	timed_delay_start = systick;
	timed_delay_duration = delay_ms;
	next_app_state = next_state;
	app_state = APP_STATE_TIMED_DELAY;
}

void reset_bridge(void)
{
	CS3_EN_set_level(false);	// CS3 (EN) to 0
	Delay_Ms(1000);
	CS3_EN_set_level(true);		// CS3 (EN) to 1
	Delay_Ms(1000);
}

void State_Machine(void)
{
	switch (app_state) {
		case APP_STATE_INIT:
			app_state = APP_STATE_RESET_BRIDGE;
			break;
	    case APP_STATE_RESET_BRIDGE:
	        printf("Resetting bridge hardware...");
			reset_bridge();
	        printf("complete\r\n");
	        app_state = APP_STATE_INIT_BRIDGE;
	        break;
	    case APP_STATE_INIT_BRIDGE:
	        printf("Initializing bridge\r\n");
	        Send_Command("AT\n");
	        app_state = APP_STATE_INIT_BRIDGE_CONFIRM;
	        break;
	    case APP_STATE_INIT_BRIDGE_CONFIRM:
	        if (new_response_available && isOKResponse(last_response)) {
		        printf("Bridge initialization complete\r\n");
		        app_state = APP_STATE_CONNECT_WIFI;
		        } else if (Response_Elapsed_Time() > 1000) {
		        printf("ERROR: Bridge not responding\r\n");
		        app_state = APP_STATE_RESET_BRIDGE;
	        }
	        break;
	    case APP_STATE_CONNECT_WIFI:
	        printf("Connecting to Wi-Fi\r\n");
	        sprintf(command, "AT+CWIFI={\"ssid\":\"%s\",\"password\":\"%s\"}\n",
	        WIFI_SSID, WIFI_PASSWORD);
	        Send_Command(command);
	        app_state = APP_STATE_CONNECT_WIFI_CONFIRM;
	        break;
	        case APP_STATE_CONNECT_WIFI_CONFIRM:
	        if (new_response_available) {
		        if (isOKResponse(last_response)) {
			        printf("Wi-Fi connect successful\r\n");
			        app_state = APP_STATE_CONNECT_MQTT;
			        } else {
			        printf("ERROR: Wi-Fi connect failed, will retry\r\n");
			        set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
		        }
		        } else if (Response_Elapsed_Time() > 20000) {
		        printf("ERROR: Wi-Fi connect timed out, will retry\r\n");
		        set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
	        }
	        break;
	    case APP_STATE_CONNECT_MQTT:
	        printf("Connecting to MQTT broker\r\n");
	        sprintf(command, "AT+CMQTT={\"host\":\"%s\",\"port\":%lu,\"username\":\"%s\",\"password\":\"%s\"}\n",
	        MQTT_BROKER, MQTT_PORT, MQTT_USERNAME, MQTT_PASSWORD);
	        Send_Command(command);
	        app_state = APP_STATE_CONNECT_MQTT_CONFIRM;
	        break;
	    case APP_STATE_CONNECT_MQTT_CONFIRM:
	        if (new_response_available) {
		        if (isOKResponse(last_response)) {
			        printf("MQTT connect successful\r\n");
			        app_state = APP_STATE_PUBLISH_SENSOR_DATA;
			        } else {
			        printf("ERROR: MQTT connect failed, will retry\r\n");
			        set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
		        }
		        } else if (Response_Elapsed_Time() > 10000) {
		        printf("ERROR: MQTT connect timed out, will retry\r\n");
		        set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
	        }
	        break;
	    case APP_STATE_PUBLISH_SENSOR_DATA:
	        Read_Sensors(&sensorData);
	        printf("Building publish message\r\n");
	        sprintf(command,
	        "AT+PUBLISH={\"topic\":\"%s\",\"msg\":\"{\\\"event_data\\\":{\\\"iteration\\\":%u,\\\"timestamp\\\":%u,\\\"button\\\":%u,\\\"temp\\\":%d.%02d,\\\"amb_temp\\\":%d.%02d}}\"}\n",
	        MQTT_PUB_TOPIC,
	        (unsigned)sensorData.iteration, (unsigned)sensorData.timestamp, (unsigned)sensorData.buttonState,
			sensorData.temp_f / 100, sensorData.temp_f % 100,
			sensorData.amb_temp_f / 100, sensorData.amb_temp_f % 100
	        );
	        printf("%s\r\n", command);
#if ENABLE_PUBLISH == 1
	        Send_Command(command);
	        LED0_On();
	        app_state = APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM;
#else
	        set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
#endif
	        break;
	    case APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM:
	        if (new_response_available) {
		        LED0_Off();
		        if (isOKResponse(last_response)) {
			        printf("MQTT publish successful\r\n");
			        fail_count = 0;
			        set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
			        } else {
			        printf("ERROR: MQTT publish failed\r\n");
			        if (++fail_count >= 3) {
				        app_state = APP_STATE_DISCONNECT_WIFI;
				        } else {
				        set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
			        }
		        }
		        } else if (Response_Elapsed_Time() > 10000) {
		        LED0_Off();
		        printf("ERROR: MQTT publish timed out\r\n");
		        if (++fail_count >= 3) {
			        app_state = APP_STATE_DISCONNECT_WIFI;
			        } else {
			        // try again with no additional delay
		        }
	        }
	        break;
	    case APP_STATE_DISCONNECT_MQTT:
	        /* not currently used */
	        break;
	    case APP_STATE_DISCONNECT_WIFI:
	        printf("Disconnecting Wi-Fi\r\n");
	        Send_Command("AT+DWIFI\n");
	        app_state = APP_STATE_DISCONNECT_WIFI_CONFIRM;
	        break;
	    case APP_STATE_DISCONNECT_WIFI_CONFIRM:
	        if (new_response_available) {
		        if (isOKResponse(last_response)) {
			        printf("Wi-Fi disconnect successful\r\n");
			        app_state = new_app_state(APP_STATE_INIT);
			        } else {
			        printf("ERROR: Wi-Fi disconnect failed\r\n");
			        app_state = new_app_state(APP_STATE_INIT);
		        }
		        } else if (Response_Elapsed_Time() > 10000) {
		        printf("ERROR: Wi-Fi disconnect timed out\r\n");
		        app_state = new_app_state(APP_STATE_INIT);
	        }
	        break;
	    case APP_STATE_TIMED_DELAY:
	        if ((systick - timed_delay_start) >= timed_delay_duration) {
		        app_state = new_app_state(APP_STATE_INIT);
	        }
	    case APP_STATE_NONE:
	        default:
	        break;
        }	
}
